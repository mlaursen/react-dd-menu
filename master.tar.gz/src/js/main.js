import React from 'react'

import Example from './Example'

React.render(<Example />, document.body);
